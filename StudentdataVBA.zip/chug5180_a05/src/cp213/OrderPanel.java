package cp213;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cp213.OrderPanel.PrintListener;
import cp213.OrderPanel.QuantityListener;

/**
 * The GUI for the Order class.
 *
 * @author your name here
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2022-11-20
 */
@SuppressWarnings("serial")
public class OrderPanel extends JPanel {

    // Attributes
    private Menu menu = null; // Menu attached to panel.
    private final Order order = new Order(); // Order to be printed by panel.
    // GUI Widgets
    private final JButton printButton = new JButton("Print");
    private final JLabel subtotalLabel = new JLabel("0");
    private final JLabel taxLabel = new JLabel("0");
    private final JLabel totalLabel = new JLabel("0");

    private JLabel nameLabels[] = null;
    private JLabel priceLabels[] = null;
    // TextFields for menu item quantities.
    private JTextField quantityFields[] = null;

    /**
     * Displays the menu in a GUI.
     *
     * @param menu The menu to display.
     */
    public OrderPanel(final Menu menu) {
	this.menu = menu;
	this.nameLabels = new JLabel[this.menu.size()];
	this.priceLabels = new JLabel[this.menu.size()];
	this.quantityFields = new JTextField[this.menu.size()];
	this.layoutView();
	this.registerListeners();
    }

    /**
     * Implements an ActionListener for the 'Print' button. Prints the current
     * contents of the Order to a system printer or PDF.
     */
    private class PrintListener implements ActionListener {

	@Override
	public void actionPerformed(final ActionEvent e) {
		PrinterJob job = PrinterJob.getPrinterJob();
		
		job.setPrintable(order);
		boolean doPrint = job.printDialog();
		if (doPrint) {
		    try {
		        job.print();
		    } catch (PrinterException a) {
		        // Unsuccessful completion attempt
		    }
		}
	}
    }

    /**
     * Implements a FocusListener on a quantityField. Requires appropriate
     * FocusListener methods.
     */
    private class QuantityListener implements FocusListener {
    	public void focusGained(final FocusEvent e) {
    		
        	
        	for(int i=0; i<menuList.size(); i++) {
        		
        		try {
        			Integer entry = Integer.parseInt(textFields.get(i).getText());
        			
        			if(entry<1) 
        				{
        				textFields.get(i).setText("0");
        				order.update(menuList.get(i), 0);
        				}
        			
        			else 
        				{
        				order.update(menuList.get(i), Integer.parseInt(textFields.get(i).getText()));	
        	    		}
        			
        		} catch (Exception a) {
        			
        			textFields.get(i).setText("0");
        			order.update(menuList.get(i), 0);
        			
        		}
        		

        		subtotalLabel.setText(String.format("$%5.2f", order.getSubTotal()));
        		taxLabel.setText(String.format("$%5.2f", order.getTaxes()));
        		totalLabel.setText(String.format("$%5.2f", order.getTotal()));    		
        		
        		}
        	}
        	
        	public void focusLost(final FocusEvent e) {
        		// No code needed for this
        	}
        }
    
    private final ArrayList<JTextField> textFields = new ArrayList<JTextField>();
    private final ArrayList<MenuItem> menuList = new ArrayList<MenuItem>();
    

    /**
     * Layout the panel.
     */
    private void layoutView() {
    	this.layoutView(menu);
    	this.registerListeners();
    	
    }

        /**
         * Lays out the individual model views within the main frame.
         */
        private void layoutView(final Menu menu) {
        	//Stores menu in menuList array
        	for(int i=0;i<menu.size();i++) {
        		this.menuList.add(menu.getItem(i));
        	}
        	
        	//Item Panel
        	JPanel itemPanel = new JPanel(new GridLayout(menu.size()+4, 1, 20, 20));
        	
        	itemPanel.add(new JLabel("Item"));
        	
        	for(int i=0;i<menu.size();i++) {
        		itemPanel.add(new JLabel(menu.getItem(i).getName()));
        	}
        	itemPanel.add(new JLabel("Subtotal:"));
        	itemPanel.add(new JLabel("Tax:"));
        	itemPanel.add(new JLabel("Total:"));
        	
        	//Prices Panel
        	JPanel pricePanel = new JPanel(new GridLayout(menu.size()+4, 1, 20, 20));
        	
        	pricePanel.add(new JLabel("Price"));
        	
        	for(int i=0;i<menu.size();i++) {
        		pricePanel.add(new JLabel("$" + menu.getItem(i).getPrice().toString()));
        	}
        	
        	//Quantity and Totals Panel
        	JPanel quantityPanel = new JPanel(new GridLayout(menu.size()+4, 1, 16, 16));
        	
        	quantityPanel.add(new JLabel("Quantity"));
        	

        	for(int i=0;i<menu.size();i++) {
        		JTextField textField = new JTextField();
        		this.textFields.add(textField);
        		quantityPanel.add(textField);
        		
        	}
        	
        	quantityPanel.add(this.subtotalLabel);
        	quantityPanel.add(this.taxLabel);
        	quantityPanel.add(this.totalLabel);
   

        	
        	setLayout(new GridLayout(1,3));
        	this.add(itemPanel);
        	this.add(pricePanel);
        	this.add(quantityPanel);
        	this.add(printButton);
        }

    /**
     * Register the widget listeners.
     */
    private void registerListeners() {
	// Register the PrinterListener with the print button.
		this.printButton.addActionListener(new PrintListener());
	
		this.subtotalLabel.addFocusListener(new QuantityListener());
		this.taxLabel.addFocusListener(new QuantityListener());
		this.totalLabel.addFocusListener(new QuantityListener());
		
		for(int i=0;i<this.textFields.size();i++) {
			this.textFields.get(i).addFocusListener(new QuantityListener());
		}
    }
}