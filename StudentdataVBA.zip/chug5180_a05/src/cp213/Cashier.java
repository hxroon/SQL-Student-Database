package cp213;

import java.util.Scanner;

/**
 * Wraps around an Order object to ask for MenuItems and quantities.
 *
 * @author your name here
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2022-11-20
 */
public class Cashier {

    // Attributes
    private Menu menu = null;

    /**
     * Constructor.
     *
     * @param menu A Menu.
     */
    public Cashier(Menu menu) {
	this.menu = menu;
    }

    /**
     * Prints the menu.
     */
    private void printCommands() {
	System.out.println("\nMenu:");
	System.out.println(menu.toString());
	System.out.println("Press 0 when done.");
	System.out.println("Press any other key to see the menu again.\n");
    }

    /**
     * Asks for commands and quantities. Prints a receipt when all orders have been
     * placed.
     *
     * @return the completed Order.
     */
    public Order takeOrder() {
		System.out.println("Welcome to WLU Foodorama!");
		this.printCommands();
		
		Scanner keyboard = new Scanner(System.in);
		Order order = new Order();
		
		int quantity = 0;
		int itemNumber = 0;
		boolean quit = false;
		boolean command = true;
		String userinput = "";
		
		
		while(!quit)
			{
			try{
				System.out.print("Command: ");
				userinput=keyboard.next();
				
				if(userinput.equals("0")) {
					quit = true;
					keyboard.close();
				} else {
					command = true;
					itemNumber=Integer.parseInt(userinput)-1;
					command = false;
					
					System.out.print("How many do you want?: ");
					userinput = keyboard.next();
					quantity = Integer.parseInt(userinput);
				
					order.add(menu.getItem(itemNumber), quantity);
					
				}
			} catch (Exception e) {
				keyboard.nextLine();
				System.out.println("Not a valid number");
				
				if(command==true) {
					this.printCommands();
				}
				
			} 
		
			}

		System.out.println("-".repeat(40));
		System.out.println("Receipt");
		System.out.println(order.toString());
	
	return order;
    }
}